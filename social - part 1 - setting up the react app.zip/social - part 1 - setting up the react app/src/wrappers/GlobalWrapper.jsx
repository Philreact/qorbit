import React from 'react'

export const GlobalWrapper = ({children}) => {
  return (
    <>{children}</>
  )
}
